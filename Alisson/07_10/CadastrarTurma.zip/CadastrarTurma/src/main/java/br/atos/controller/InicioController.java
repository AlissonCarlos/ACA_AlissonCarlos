package br.atos.controller;

import javax.faces.bean.ManagedBean;

@ManagedBean(name="inicio")
public class InicioController {
	
	public String cadastrarProfessor() {
		return "cadastrarProfesso.xhtml";
	}
	
	public String cadastrarEstudante(){
		return "cadastrarEstudante.xhtml";
	}

}
