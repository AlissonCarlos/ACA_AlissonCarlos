package br.atos.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.atos.modelo.Endereco;
import br.atos.modelo.Estudante;

@ManagedBean(name="estudanteBean")
@SessionScoped
public class CadastroEstudanteController {
	
	private String cidadeBean;
	private String ruaBean;
	private String casaBean;
	
	Estudante estudante = new Estudante();
	private List<Estudante> estudantes = new ArrayList<>();
	
	
	public String salvarEstudante() {
		Endereco end = new Endereco();
		end.setCidade(cidadeBean);
		end.setRua(ruaBean);
		end.setCasa(casaBean);
		estudante.setEndereco(end);
		estudantes.add(estudante);
		limparEstudante();
		return "";
	}
	
	public String deletarEstudante(Estudante estudante) {
		estudantes.remove(estudante);
		return "";
	}

	private void limparEstudante() {
		this.estudante = new Estudante();
	}

	public Estudante getEstudante() {
		return estudante;
	}

	public void setEstudante(Estudante estudante) {
		this.estudante = estudante;
	}

	public List<Estudante> getEstudantes() {
		return estudantes;
	}

	public void setEstudantes(List<Estudante> estudantes) {
		this.estudantes = estudantes;
	}

	public String getCidadeBean() {
		return cidadeBean;
	}

	public void setCidadeBean(String cidadeBean) {
		this.cidadeBean = cidadeBean;
	}

	public String getRuaBean() {
		return ruaBean;
	}

	public void setRuaBean(String ruaBean) {
		this.ruaBean = ruaBean;
	}

	public String getCasaBean() {
		return casaBean;
	}

	public void setCasaBean(String casaBean) {
		this.casaBean = casaBean;
	}
	
}
