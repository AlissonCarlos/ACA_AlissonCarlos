package br.atos.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.atos.modelo.Endereco;
import br.atos.modelo.Professor;

@ManagedBean(name="cadastro")
@SessionScoped
public class CadastroTurmaController {
	
	private String nomeBean;
	private String cpfBean;
	private String disciplinaBean;
	private double salarioBean;
	private String cidadeBean;
	private String ruaBean;
	private String casaBean;
	
	private List<Professor> professores = new ArrayList<>();
	
	public String salvarProfessor() {
		Professor professor = new Professor();
		professor.setNome(nomeBean);
		professor.setCpf(cpfBean);
		professor.setDisciplina(disciplinaBean);
		professor.setSalario(salarioBean);
		Endereco end = new Endereco();
		end.setCidade(cidadeBean);
		end.setRua(ruaBean);
		end.setCasa(casaBean);
		professor.setEndereco(end);
		
		professores.add(professor);
		return "";
	}

	public String getNomeBean() {
		return nomeBean;
	}

	public void setNomeBean(String nomeBean) {
		this.nomeBean = nomeBean;
	}

	public String getCpfBean() {
		return cpfBean;
	}

	public void setCpfBean(String cpfBean) {
		this.cpfBean = cpfBean;
	}

	public String getDisciplinaBean() {
		return disciplinaBean;
	}

	public void setDisciplinaBean(String disciplinaBean) {
		this.disciplinaBean = disciplinaBean;
	}

	public double getSalarioBean() {
		return salarioBean;
	}

	public void setSalarioBean(double salarioBean) {
		this.salarioBean = salarioBean;
	}

	public List<Professor> getProfessores() {
		return professores;
	}

	public void setProfessores(List<Professor> professores) {
		this.professores = professores;
	}

	public String getCidadeBean() {
		return cidadeBean;
	}

	public void setCidadeBean(String cidadeBean) {
		this.cidadeBean = cidadeBean;
	}

	public String getRuaBean() {
		return ruaBean;
	}

	public void setRuaBean(String ruaBean) {
		this.ruaBean = ruaBean;
	}

	public String getCasaBean() {
		return casaBean;
	}

	public void setCasaBean(String casaBean) {
		this.casaBean = casaBean;
	}
	
	
	
}
