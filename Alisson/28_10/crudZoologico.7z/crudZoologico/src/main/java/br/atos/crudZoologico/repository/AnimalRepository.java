package br.atos.crudZoologico.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.crudZoologico.model.Animal;

public interface AnimalRepository extends CrudRepository<Animal, Long> {
	Animal findById(long id);
}
