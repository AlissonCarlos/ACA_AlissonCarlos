package br.atos.crudZoologico.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.crudZoologico.model.Animal;
import br.atos.crudZoologico.repository.AnimalRepository;


@RequestMapping(value="/animal")
@Controller
public class CadastroAnimalController {
	
	@Autowired
	AnimalRepository animalRepository;
	
	@RequestMapping(value = "/cadastroAnimal", method = RequestMethod.GET)
	public String cadastroAnimal() {
		return "/animal/cadastroAnimal";
	}
	
	@RequestMapping(value = "/cadastroAnimal", method = RequestMethod.POST)
	public String cadastroAnimal(Animal animal) {
		animalRepository.save(animal);
		return "/animal/cadastroAnimal";
	}
	
	@RequestMapping(value = "/listarAnimal", method = RequestMethod.GET)
	public ModelAndView listaAnimais() {
		ModelAndView modelAndView = new ModelAndView("/animal/listarAnimal"); // Objeto que recebe o "endereço de uma pagina HTML" e um ou mais objetos que também podem ser uma lista.
		Iterable<Animal> listarAnimal= animalRepository.findAll(); // Busca todos titulares no banco de dados
		modelAndView.addObject("listarAnimal", listarAnimal);// Adiciona a lista de titulares no objeto "ModelAndView";
		return modelAndView;
	} 
	
	@GetMapping(value = "/deletaAnimal/{id}")
	public String deletaAnimal(@PathVariable ("id") long idReq) {
		Animal animal = animalRepository.findById(idReq);
		animalRepository.delete(animal);
		return "redirect:/animal/listarAnimal";
	}
	
	@GetMapping(value = "/editarAnimal/{id}")
	public ModelAndView editarAnimal(@PathVariable ("id") long idReq) {
		Animal animal = animalRepository.findById(idReq);
		ModelAndView modelAndView = new ModelAndView("/animal/editarAnimal");
		modelAndView.addObject("animal", animal);
		
		return modelAndView;
	}
	
	@RequestMapping(value = "/alterarAnimal", method = RequestMethod.POST)
	public String alterarAnimal(Animal animal) {
		animalRepository.save(animal);
		return "redirect:/animal/listarAnimal";
	}
	
}
