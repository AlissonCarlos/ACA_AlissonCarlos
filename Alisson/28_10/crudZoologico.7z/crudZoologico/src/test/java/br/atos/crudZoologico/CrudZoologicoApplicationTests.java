package br.atos.crudZoologico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudZoologicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
