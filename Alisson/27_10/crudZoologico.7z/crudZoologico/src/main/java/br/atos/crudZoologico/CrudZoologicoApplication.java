package br.atos.crudZoologico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudZoologicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudZoologicoApplication.class, args);
	}

}
