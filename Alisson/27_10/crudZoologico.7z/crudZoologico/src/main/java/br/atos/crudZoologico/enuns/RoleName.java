package br.atos.crudZoologico.enuns;

public enum RoleName {
	
	ROLE_ADMIN,
	ROLE_USER;
}
