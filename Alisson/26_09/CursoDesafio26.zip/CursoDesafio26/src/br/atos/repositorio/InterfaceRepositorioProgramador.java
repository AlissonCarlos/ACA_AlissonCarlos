package br.atos.repositorio;

import java.util.List;

import br.atos.model.Programador;


public interface InterfaceRepositorioProgramador {

	public boolean salvarProgramador(Programador programador);
	public List<Programador> listarProgramador();
	
	
}
