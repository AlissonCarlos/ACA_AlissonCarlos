package br.atos.repositorio;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.atos.model.Gerente;


public class RepositorioGerente implements InterfaceRepositorioGerente{


    private List<Gerente> gerentes = new ArrayList<>();
    boolean sucesso = false;

    @Override
    public List<Gerente> listarGerentes() {
        return this.gerentes;
    }
    
    @Override
    public void deletarGerente(Gerente gerente) {
        try {
            gerentes = listarGerentes();
            if(!gerentes.stream()
                    .filter(g->g.getCpf().equals(gerente.getCpf())).findFirst().isPresent()){
            	JOptionPane.showMessageDialog(null, "Nenhum gerente encontrado com esse cpf: "+gerente.getCpf());
                System.out.printf("\nNenhum gerente encontrado com esse cpf: %s",gerente.getCpf());
            }
            for (Gerente g:gerentes) {
                if(g.getCpf().equals(gerente.getCpf())){
                	gerentes.remove(g);
                	  JOptionPane.showMessageDialog(null, "Funcion�rio exclu�do com Sucesso!");
                   break;
                }
            }
        }
        catch (Exception exception){
        	JOptionPane.showMessageDialog(null, "catch: Erro ao exlcuir gerente!!!"+exception.getMessage());
            System.out.println("\ncatch: Erro ao exlcuir gerente!!!!\n");
        }
    }

	public List<Gerente> getGerentes() {
		return gerentes;
	}

	public void setGerentes(List<Gerente> gerentes) {
		this.gerentes = gerentes;
	}
    
}
