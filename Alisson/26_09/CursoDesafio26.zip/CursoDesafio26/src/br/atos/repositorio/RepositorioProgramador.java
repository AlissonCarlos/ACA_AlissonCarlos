package br.atos.repositorio;

import java.util.ArrayList;
import java.util.List;

import br.atos.model.Programador;

public class RepositorioProgramador implements InterfaceRepositorioProgramador {
	
	
	List<Programador> listaDeProgramadores = new ArrayList<>();
	
	@Override
	public boolean salvarProgramador(Programador programador) {
		try {
			listaDeProgramadores.add(programador);
			
		} catch (Exception e) {
			System.out.println("Deu erro no cadastro" + e);
			return false;
		}
		return true;
	}

	@Override
	public List<Programador> listarProgramador() {
		// TODO Auto-generated method stub
		return listaDeProgramadores;
	}

	public Programador BuscarProgramador(String cpf) {
		for(Programador programador: listaDeProgramadores) {
			if(programador.getCpf().equals(cpf)) {
				return programador;
			}
		}
		return null;
	}

	public boolean alterarProgramador(Programador programadorAtual, Programador programadorNovo) {
		for(Programador programador: listaDeProgramadores) {
			if(programador == programadorAtual) {
				listaDeProgramadores.remove(programadorAtual);
				listaDeProgramadores.add(programadorNovo);
				return true;
			}
		}
		return false;
	}

}