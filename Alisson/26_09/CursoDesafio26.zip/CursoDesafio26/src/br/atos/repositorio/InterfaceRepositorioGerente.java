package br.atos.repositorio;

import java.util.List;

import br.atos.model.Gerente;

public interface InterfaceRepositorioGerente {

	void deletarGerente(Gerente gerente);
	List<Gerente> listarGerentes();
}
