package br.atos.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Programador;
import br.atos.repositorio.RepositorioProgramador;
import br.atos.telas.telas.TelaAlterar;

public class AlterarProgramadorControle implements ActionListener {
	
	JFrame frameListarProgramador;
	JFrame frameMenuInicial;
	JTextField cpf;
	
	RepositorioProgramador repositorioProgramador;
	TelaAlterar telaAlterar;
	
	
	public AlterarProgramadorControle(JFrame frameListarProgramador, JFrame frameMenuInicial, JTextField cpf, RepositorioProgramador repositorioProgramador) {
		super();
		this.frameListarProgramador = frameListarProgramador;
		this.frameMenuInicial = frameMenuInicial;
		this.cpf = cpf;
		this.repositorioProgramador = repositorioProgramador;
	}





	@Override
	public void actionPerformed(ActionEvent e) {
		
		String botaoAcionado = e.getActionCommand();
		
		if(botaoAcionado.toUpperCase().equals("botoaVoltar".toUpperCase())){
			frameMenuInicial.setVisible(true);
			frameListarProgramador.setVisible(false);
		}
		
		Programador programadorAtual = new Programador();
		
		programadorAtual = repositorioProgramador.BuscarProgramador(cpf.getText());
		
		if (!(programadorAtual == null)) {
			frameListarProgramador.setVisible(false);
			telaAlterar.alterarProgramador(frameMenuInicial, repositorioProgramador, programadorAtual);
		}
	
	}

}
