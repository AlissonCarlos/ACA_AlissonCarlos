package br.atos.telas.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.atos.model.Programador;
import br.atos.repositorio.RepositorioProgramador;
import br.atos.telas.controleTelas.TelaRegistroControle;


public class TelaAlterar {

	
	public void  alterarProgramador(JFrame frameMenuInicial, RepositorioProgramador repositorioProgramador, Programador programadorAtual) {
		
		
		String nomeTexto = "Digite o nome do progrador:";
		String cpfTexto = "Digite o CPF:";
		String estadoTexto = "Digite o Estado:";
		
		JFrame frameTelaRegistro = new JFrame();
		frameTelaRegistro.setSize(200, 300);
		frameTelaRegistro.setTitle("Inserir Programador");
		frameTelaRegistro.setLocation(300,300);
		
		JPanel painelTelaRegistro = new JPanel();
		
		JLabel nomeTextoLabel = new JLabel(nomeTexto );
		painelTelaRegistro.add(nomeTextoLabel);
		
		JTextField nomeTextField = new JTextField(10);
		painelTelaRegistro.add(nomeTextField);
		
		
		JLabel cpfTextoLabel = new JLabel(cpfTexto);
		painelTelaRegistro.add(cpfTextoLabel);
		
		JTextField cpfTextField = new JTextField(10);
		painelTelaRegistro.add(cpfTextField);
		
		JLabel estadoTextoLabel = new JLabel(estadoTexto);
		painelTelaRegistro.add(estadoTextoLabel);
		
		JTextField estadoTextField = new JTextField(10);
		painelTelaRegistro.add(estadoTextField);
		
		JButton botaoCadastrar = new JButton("Registrar");
		painelTelaRegistro.add(botaoCadastrar);
		
		frameTelaRegistro.add(painelTelaRegistro);
		
		
		frameTelaRegistro.setVisible(true);
		
		TelaRegistroControle telaRegistroControle = new TelaRegistroControle(frameTelaRegistro, frameMenuInicial, nomeTextField, cpfTextField, estadoTextField, repositorioProgramador);
		botaoCadastrar.addActionListener(telaRegistroControle);
	}
	
	
}
