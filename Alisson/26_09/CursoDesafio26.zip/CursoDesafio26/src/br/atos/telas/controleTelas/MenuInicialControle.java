package br.atos.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.repositorio.RepositorioProgramador;
import br.atos.telas.telas.AlterarProgramador;


public class MenuInicialControle implements ActionListener {

	JTextField opcaoMenuJTextField;
	JFrame frameMenuInicial;
	
	ListarProgramador listarProgramador = new ListarProgramador();
	
	TelaRegistro telaRegistro = new TelaRegistro();
	
	RepositorioProgramador repositorioProgramador = new RepositorioProgramador();
	
	AlterarProgramador alterarProgramador = new AlterarProgramador();
	
	public MenuInicialControle() {
		
	}
	
	public MenuInicialControle(JTextField opcaoMenuJTextFieldCr,JFrame frameMenuInicialCr) {
		this.opcaoMenuJTextField = opcaoMenuJTextFieldCr;
		this.frameMenuInicial = frameMenuInicialCr;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(opcaoMenuJTextField.getText().equals("1")|| opcaoMenuJTextField.getText().equals("2") || opcaoMenuJTextField.getText().equals("3")
				|| opcaoMenuJTextField.getText().equals("5")){
			
			frameMenuInicial.setVisible(false);
			
			switch (opcaoMenuJTextField.getText()) {
			case "1":
				telaRegistro.registrarProgramador(opcaoMenuJTextField, frameMenuInicial, repositorioProgramador);
				
				System.out.println("Cadastre o programador!");
				break;
			
			case "2":
				
				listarProgramador.apresentarLista(repositorioProgramador.listarProgramador(), frameMenuInicial);
				System.out.println("Lista programadores");
				
				break;
			
			case "3":
				System.out.println("Voc� encerrou");
				break;
				
			case "5":
				alterarProgramador.buscarProgramador(frameMenuInicial, repositorioProgramador);
			break;
			}
		}else {
			
			System.out.println("Op��o Invalida!!");
		}
		
	}

}
