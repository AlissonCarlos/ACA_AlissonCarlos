package br.atos.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.atos.model.Gerente;
import br.atos.repositorio.RepositorioGerente;
import br.atos.telas.telas.TelasExcluir;


public class ExcluirControle implements ActionListener{

	JFrame frameMenuInicial;
	JFrame frameDeletaGerente;
	
	JTextField nomeTextField;
	JTextField cpfTextField;
	JTextField estadoTextField;
	
	RepositorioGerente repositorioGerenteImpl;
	
	boolean validarDeletar = false;

	
	public ExcluirControle(JTextField cpfTextField, JFrame frameTelaDelete, JFrame frameMenuInicial, RepositorioGerente repositorioGerenteImpl) {
		super();
		this.frameMenuInicial = frameMenuInicial;
		this.frameDeletaGerente = frameTelaDelete;
		this.repositorioGerenteImpl = repositorioGerenteImpl;
		this.cpfTextField = cpfTextField;
	}
	
	public ExcluirControle() {
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("exlcuir");
		if((cpfTextField!=null
				&& cpfTextField.getText()!=null
				&& cpfTextField.getText().equals(""))
				|| cpfTextField.getText().equals(null)){
	    	JOptionPane.showMessageDialog(null, "CPF Necess�rio!");
	    }
		else {
			acionarExcluir();
			TelasExcluir telaExcluir = new TelasExcluir();
			telaExcluir.excluir(frameMenuInicial, repositorioGerenteImpl);
			frameDeletaGerente.dispose();
		}
	}

	
	private void acionarExcluir() {
		Gerente gerente = new Gerente();
		gerente.setCpf(cpfTextField.getText());		
		repositorioGerenteImpl.deletarGerente(gerente);
	}

}
