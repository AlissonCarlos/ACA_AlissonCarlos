package br.atos.telas.telas;

import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import br.atos.model.Gerente;
import br.atos.repositorio.RepositorioGerente;
import br.atos.telas.controleTelas.ExcluirControle;

public class TelasExcluir {
	
	public void excluir(JFrame frameMenuInicial, RepositorioGerente repositorioGerente) {

	List<Gerente>listaGerente = repositorioGerente.listarGerentes();
	int quantidadeDeLinhas = listaGerente.size();
	
	String [][] tabelaString = new String [quantidadeDeLinhas][3];
	
	int posicaoLinha = 0;
	int posicaoColuna = 0;
	
	for(Gerente gerente: listaGerente) {
		
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getNome();
		posicaoColuna++;
		
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getCpf();
		posicaoColuna++;
		
		
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getEstado();
		posicaoColuna = 0;
		posicaoLinha++;
	
	}
	
	
	String colunasTitulos[] = {"Nome", "Cpf", "Estado"};
	
	JFrame frameDeletaGerente = new JFrame();
	frameDeletaGerente.setSize(500,600);
	
	JTable tabelaProgramador = new JTable(tabelaString,colunasTitulos);
	tabelaProgramador.setBounds(30,40,200,300);
	
	JScrollPane scrollPaneTabela = new JScrollPane(tabelaProgramador);
	JPanel paneldeletarGerente= new JPanel();
	
	paneldeletarGerente.add(scrollPaneTabela);
	
	JLabel nomeTextoLabel = new JLabel("CPF para Exluir");
	paneldeletarGerente.add(nomeTextoLabel);
	
	JTextField opcaoCpfTextField = new JTextField(5);
	paneldeletarGerente.add(opcaoCpfTextField);
	
	JButton botaoMenu = new JButton("Deletar");
	paneldeletarGerente.add(botaoMenu);
	
	JButton botaoMenuInicial = new JButton("Menu inicial");
	paneldeletarGerente.add(botaoMenuInicial);
	
	frameDeletaGerente.add(paneldeletarGerente);
	frameDeletaGerente.setVisible(true);
	
	
	ExcluirControle menuDeleteControle = new ExcluirControle(opcaoCpfTextField, frameDeletaGerente, frameMenuInicial, repositorioGerente);
	botaoMenu.addActionListener(menuDeleteControle);
	}
}
