package br.atos.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Programador;
import br.atos.repositorio.RepositorioProgramador;

public class AlterarControle implements ActionListener {
	
	JFrame telaAlterar;
	JFrame menuInicial;
	
	//Dados do Programador
	JTextField nome;
	JTextField cpf;
	JTextField estado;
	

	RepositorioProgramador repositorioProgramador = new RepositorioProgramador();
	Programador programador = new Programador();
	
	
	public AlterarControle(JFrame telaAlterar, JFrame menuInicial, JTextField nome, JTextField cpf, JTextField estado,
			RepositorioProgramador repositorioProgramador, Programador programador) {
		super();
		telaAlterar = telaAlterar;
		this.menuInicial = menuInicial;
		this.nome = nome;
		this.cpf = cpf;
		this.estado = estado;
		this.repositorioProgramador = repositorioProgramador;
		this.programador = programador;
	}




	@Override
	public void actionPerformed(ActionEvent e) {
		alterarProgramador();
		menuInicial.setVisible(true);
		telaAlterar.setVisible(false);
	}


	private void alterarProgramador() {
		Programador pro = new Programador();
		pro.setNome(nome.getText());
		pro.setCpf(cpf.getText());
		pro.setEstado(estado.getText());
	}

}
