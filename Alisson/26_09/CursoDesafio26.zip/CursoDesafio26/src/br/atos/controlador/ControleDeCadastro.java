package br.atos.controlador;

import br.atos.telas.telas.MenuInicial;

public class ControleDeCadastro {

	public void iniciarPrograma() {
		MenuInicial menuInicial = new MenuInicial();
		menuInicial.apresentarMenuInicial();
		
		
	}
	
	
}
