package br.atos;

import br.atos.controlador.ControleDeCadastro;

public class Principal {
	
	public static void main(String[] args) {

		ControleDeCadastro controleDeCadastro = new ControleDeCadastro();
		controleDeCadastro.iniciarPrograma();
	}

}
