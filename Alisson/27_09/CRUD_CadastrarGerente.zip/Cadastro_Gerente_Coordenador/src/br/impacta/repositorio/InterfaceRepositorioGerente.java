package br.impacta.repositorio;

import java.util.List;

import br.impacta.model.Gerente;

public interface InterfaceRepositorioGerente {

	public List<Gerente> listarGerente();
	public boolean salvarGerente(Gerente gerente);
	public boolean alterarGerente(Gerente gerenteAtual, Gerente gerenteNovo);
	Gerente BuscarGerente(String cpf);
	
}
