package br.impacta.repositorio;

import java.util.ArrayList;
import java.util.List;

import br.impacta.model.Gerente;

public class RepositorioGerente implements InterfaceRepositorioGerente {
	
	
	List<Gerente> listarGerente = new ArrayList<>();
	
	@Override
	public boolean salvarGerente(Gerente gerente) {
		try {
			listarGerente.add(gerente);
			
		} catch (Exception e) {
			System.out.println("Deu erro no cadastro" + e);
			return false;
		}
		return true;
	}

	@Override
	public List<Gerente> listarGerente() {
		return listarGerente;
	}
	
	@Override
	public Gerente BuscarGerente(String cpf) {
		
		for(Gerente gerente: listarGerente) {
			if(gerente.getCpf().equals(cpf)) {
				return gerente;
			}
		}
		return null;
	}

	@Override
	public boolean alterarGerente(Gerente gerenteAtual, Gerente gerenteNovo) {
		
		for(Gerente gerente: listarGerente) {
			if(gerente == gerenteAtual) {
				listarGerente.remove(gerenteAtual);
				listarGerente.add(gerenteNovo);
				return true;
			}
		}
		return false;
	}
	

	public boolean deletarGerente(String cpf) {
		for (Gerente gerente : listarGerente) {
			if(gerente.getCpf().equals(cpf)) {
				listarGerente.remove(gerente);
				return true;
			}
		}
		return false;
	}

}
