package br.impacta.repositorio;

import java.util.ArrayList;
import java.util.List;

import br.impacta.model.Programador;


public class RepositorioProgramador implements InterfaceRepositorioProgramador {
	
	
	List<Programador> listaDeProgramadores = new ArrayList<>();
	
	@Override
	public boolean salvarProgramador(Programador programador) {
		
		
		try {
			listaDeProgramadores.add(programador);
			
			
		} catch (Exception e) {
			System.out.println("Deu erro no cadastro" + e);
			return false;
		}
		

		return true;
	}

	@Override
	public List<Programador> listarProgramador() {
		// TODO Auto-generated method stub
		return listaDeProgramadores;
	}

	@Override
	public boolean deletarProgramador(String cpf) {
		
		for (Programador programador : listaDeProgramadores) {
			//Verificar se vai funcionar
			if(programador.getCpf().equals(cpf)) {
				
				listaDeProgramadores.remove(programador);
				return true;
			}
			
		}
		
		return false;
	}

	@Override
	public Programador BuscarProgramador(String cpf) {
		
		for(Programador programador: listaDeProgramadores) {
			if(programador.getCpf().equals(cpf)) {
				return programador;
				
			}
			
		}
		
		return null;
	}

	@Override
	public boolean alterarProgramador(Programador programadorAtual, Programador programadornovo) {
		
		for(Programador programador: listaDeProgramadores) {
			if(programador == programadorAtual) {
				listaDeProgramadores.remove(programadorAtual);
				listaDeProgramadores.add(programadornovo);
				return true;
				
			}

		}
		
		return false;
	}

}
