package br.impacta.controlador;

import br.impacta.telas.MenuInicial;
import br.impacta.telas.MenuInicialFuncionario;

public class ControleDeCadastro {

	public void iniciarPrograma() {
//		MenuInicial menuInicial = new MenuInicial();
		//Realiza a chamada da janela do MenuInicial
//		menuInicial.apresentarMenuInicial();
		
		MenuInicialFuncionario menuInicialFuncionario = new MenuInicialFuncionario();
		menuInicialFuncionario.apresentarMenuInicial();
		
		
	}
	
	
}
