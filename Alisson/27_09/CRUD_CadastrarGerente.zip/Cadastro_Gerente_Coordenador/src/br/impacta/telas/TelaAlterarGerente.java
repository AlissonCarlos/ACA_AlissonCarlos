package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.controleTelas.TelaAlterarGerenteControle;

public class TelaAlterarGerente {
	
public void  alterarGerente(JFrame frameMenuInicial, RepositorioGerente repositorioGerente, Gerente gerenteAtual) {
		
		String nomeTexto = "Digite o nome:";
		String cpfTexto = "Digite o CPF:";
		String estadoTexto = "Digite o Estado:";
		String regionalTexto = "Digite a Regional";
		String metaRegional = "Digite a Meta Regional";
		String salarioLiquido = "Digite o Salario";
		
		JFrame frameTelaRegistro = new JFrame();
		frameTelaRegistro.setSize(300, 400);
		frameTelaRegistro.setTitle("Alterar Gerente");
		frameTelaRegistro.setLocation(500,500);
		
		JPanel painelTelaRegistro = new JPanel();
		
		JLabel nomeTextoLabel = new JLabel(nomeTexto );
		painelTelaRegistro.add(nomeTextoLabel);
		
		JTextField nomeTextField = new JTextField(10);
		nomeTextField.setText(gerenteAtual.getNome());
		painelTelaRegistro.add(nomeTextField);
		
		
		JLabel cpfTextoLabel = new JLabel(cpfTexto);
		painelTelaRegistro.add(cpfTextoLabel);
		
		JTextField cpfTextField = new JTextField(10);
		cpfTextField.setText(gerenteAtual.getCpf());
		painelTelaRegistro.add(cpfTextField);
		
		JLabel estadoTextoLabel = new JLabel(estadoTexto);
		painelTelaRegistro.add(estadoTextoLabel);
		
		JTextField estadoTextField = new JTextField(10);
		estadoTextField.setText(gerenteAtual.getRegional());
		painelTelaRegistro.add(estadoTextField);
		
		JLabel regionalTextoLabel = new JLabel(regionalTexto);
		painelTelaRegistro.add(regionalTextoLabel);
		
		JTextField regionalTextField = new JTextField(10);
		regionalTextField.setText(gerenteAtual.getRegional());
		painelTelaRegistro.add(regionalTextField);
		
		JLabel metaRegionalLabel = new JLabel(metaRegional);
		painelTelaRegistro.add(metaRegionalLabel);
		
		JTextField metaRegionalTextField = new JTextField(10);
		metaRegionalTextField.setText(gerenteAtual.getMetaRegional());
		painelTelaRegistro.add(metaRegionalTextField);
		
		JLabel salarioLiquidoLabel = new JLabel(salarioLiquido);
		painelTelaRegistro.add(salarioLiquidoLabel);
		
		JTextField salarioLiquidoTextField = new JTextField(10);
		salarioLiquidoTextField.setText(gerenteAtual.getSalarioLiquido());
		painelTelaRegistro.add(salarioLiquidoTextField);
		
		JButton botaoAlterar = new JButton("Alterar");
		painelTelaRegistro.add(botaoAlterar);
		
		frameTelaRegistro.add(painelTelaRegistro);
		
		frameTelaRegistro.setVisible(true);
		
		TelaAlterarGerenteControle telaRegistroGerenteControle = 
				new TelaAlterarGerenteControle(frameTelaRegistro, frameMenuInicial, nomeTextField, 
						cpfTextField, estadoTextField, regionalTextField, metaRegionalTextField, salarioLiquidoTextField,
						repositorioGerente, gerenteAtual);
		
		botaoAlterar.addActionListener(telaRegistroGerenteControle);
	}

}
