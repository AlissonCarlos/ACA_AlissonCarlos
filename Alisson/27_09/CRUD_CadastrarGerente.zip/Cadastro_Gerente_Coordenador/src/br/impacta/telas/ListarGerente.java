package br.impacta.telas;

import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import br.impacta.model.Gerente;
import br.impacta.telas.controleTelas.ListarProgramadorControle;

public class ListarGerente {
	
	public void apresentarLista(List<Gerente> listaDeGerentes, JFrame frameMenuInicial){
		
		int quantidadeDeLinhas = listaDeGerentes.size();
		// Determina a quantidade de colunas
		int quantidadeDeColunas = 5;
		
		String [][] tabelaString = new String [quantidadeDeLinhas][quantidadeDeColunas];
		
		int posicaoLinha = 0; // Determina a posição da coluna
		int posicaoColuna = 0;// Determina a posição da linha
		
		for (Gerente gerente : listaDeGerentes) {
			
			tabelaString [posicaoLinha][posicaoColuna] = gerente.getNome();
			
			posicaoColuna++; // Incrementa a variavel coluna
			
			tabelaString [posicaoLinha][posicaoColuna] = gerente.getCpf();
			posicaoColuna++;// Incrementa a variavel coluna
			
			tabelaString [posicaoLinha][posicaoColuna] = gerente.getRegional();
			posicaoColuna++;// Incrementa a variavel coluna
			
			tabelaString [posicaoLinha][posicaoColuna] = gerente.getMetaRegional().toString();
			posicaoColuna++;// Incrementa a variavel coluna
			
			tabelaString [posicaoLinha][posicaoColuna] = gerente.getSalarioLiquido().toString();
			posicaoColuna = 0;
			posicaoLinha++; // Incrementa a Varivel linha
			
		}
		
		// Determina os titulos das coluna da lista
		String colunasTitulos[] = {"Nome", "CPF", "Regional", "Meta Regional", "Salário Liquido"};
		
		//Cria o frame (janela)
		JFrame frameListarGerente = new JFrame();
		frameListarGerente.setSize(500,600);
		
		//Cria o objeto do tipo tabela (interface grafica)
		JTable tabelaGerente = new JTable(tabelaString,colunasTitulos);
		tabelaGerente.setBounds(30,40,200,300);
		
		//Scroll
		JScrollPane scrollPaneTabela = new JScrollPane(tabelaGerente);
		JPanel panelListarGerente = new JPanel();
		
		// Adiciona o scroll pane no painel
		panelListarGerente.add(scrollPaneTabela);
		
		// Adiciona o painel no frame e habilita a visibilidade do frame
		frameListarGerente.add(panelListarGerente);
		frameListarGerente.setVisible(true);
		
		
		JButton botaoVoltar = new JButton("Menu");
		panelListarGerente.add(botaoVoltar);
		
		ListarProgramadorControle listarProgramadorControle = new ListarProgramadorControle(frameMenuInicial, frameListarGerente);
		botaoVoltar.addActionListener(listarProgramadorControle);

	}

}
