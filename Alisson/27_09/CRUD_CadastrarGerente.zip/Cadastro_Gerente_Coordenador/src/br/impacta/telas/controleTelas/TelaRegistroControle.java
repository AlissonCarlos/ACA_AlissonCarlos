package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.model.Programador;
import br.impacta.repositorio.RepositorioProgramador;

public class TelaRegistroControle implements ActionListener {

	JFrame frameTelaRegistro;
	JFrame frameMenuInicial;
	
	JTextField nomeTextField;
	JTextField cpfTextField;
	JTextField estadoTextField;
	
	//Iniciar o repositorio geral da aplicação. 
	RepositorioProgramador repositorioProgramador;
	
	boolean validarSalvar = false;

	//Contrutor recebendo os parametros(sobrecarga)
	public TelaRegistroControle(JFrame frameTelaRegistro, JFrame frameMenuInicial, JTextField nomeTextField,
			JTextField cpfTextField, JTextField estadoTextField, RepositorioProgramador repositorioProgramador) {
		super();
		this.frameTelaRegistro = frameTelaRegistro;
		this.frameMenuInicial = frameMenuInicial;
		this.nomeTextField = nomeTextField;
		this.cpfTextField = cpfTextField;
		this.estadoTextField = estadoTextField;
		this.repositorioProgramador = repositorioProgramador;
	}
	
	public TelaRegistroControle() {
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		acionarSalvar();
		frameMenuInicial.setVisible(true);
		frameTelaRegistro.setVisible(false);
		
	}

	
	//Inseri o evento da lista do repositorio.
	private void acionarSalvar() {
		
		Programador programador = new Programador();
		programador.setNome(nomeTextField.getText());
		programador.setCpf(cpfTextField.getText());
		programador.setEstado(estadoTextField.getText());
		
		validarSalvar = repositorioProgramador.salvarProgramador(programador);
		
		if(validarSalvar) {
			
			JOptionPane.showMessageDialog(null, programador.getNome() + " Foi Registrado com sucesso!");
			//System.out.println(programador.getNome() + " Foi Registrado com sucesso!");
		}else {
			JOptionPane.showMessageDialog(null, "Erro ao Cadastrar");
			System.out.println("Erro durante o cadastro");
		}
		
	}
	
	
	
	
	
}
