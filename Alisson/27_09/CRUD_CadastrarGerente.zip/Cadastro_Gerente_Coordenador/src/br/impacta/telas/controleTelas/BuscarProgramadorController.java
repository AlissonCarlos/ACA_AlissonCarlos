package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.impacta.model.Programador;
import br.impacta.repositorio.RepositorioProgramador;
import br.impacta.telas.TelaAlterar;

public class BuscarProgramadorController implements ActionListener {
	
	JFrame frameListarProgramador;
	JFrame frameMenuInicial;
	JTextField cpfField;
	
	RepositorioProgramador repositorioProgramador;
	
	TelaAlterar telaAlterar = new TelaAlterar();
	
	public BuscarProgramadorController(JFrame frameListarProgramador, JFrame frameMenuInicial, JTextField cpfField,
			RepositorioProgramador repositorioProgramador) {
		super();
		this.frameListarProgramador = frameListarProgramador;
		this.frameMenuInicial = frameMenuInicial;
		this.cpfField = cpfField;
		this.repositorioProgramador = repositorioProgramador;
	}





	@Override
	public void actionPerformed(ActionEvent e) {
		Programador programadorAtual = new Programador();
		
		programadorAtual = repositorioProgramador.BuscarProgramador(cpfField.getText());
		
		if (!(programadorAtual == null)) {
			frameListarProgramador.setVisible(false);
			telaAlterar.alterarProgramador(frameMenuInicial, repositorioProgramador, programadorAtual);
		}
	
	}

}
