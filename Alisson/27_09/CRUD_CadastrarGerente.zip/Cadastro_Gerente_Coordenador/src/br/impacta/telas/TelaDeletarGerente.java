package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.controleTelas.TelaDeletarGerenteControle;

public class TelaDeletarGerente {
	
public void  deletarGerente(JFrame frameMenuInicial, RepositorioGerente repositorioGerente) {
		
	int quantidadeDeLinhas = repositorioGerente.listarGerente().size();
	int quantidadeDeColunas = 5;
	
	String stringTextoEditar = "Digite o CPF para Alterar:";
	
	String [][] tabelaString = new String [quantidadeDeLinhas][quantidadeDeColunas];
	
	int posicaoLinha = 0; // Determina a posição da coluna
	int posicaoColuna = 0;// Determina a posição da linha
	
	// Percorrer todos os itens da lista 
	for(Gerente gerente: repositorioGerente.listarGerente()) {
		
		//Adiciona a String Nome na celula atual de acordo com o valor das variaveis 
		//posição linha e coluna
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getNome();
		
		posicaoColuna++; // Incrementa a variavel coluna
		
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getCpf();
		posicaoColuna++;// Incrementa a variavel coluna
		
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getRegional();
		posicaoColuna++;// Incrementa a variavel coluna
		
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getMetaRegional();
		posicaoColuna++;// Incrementa a variavel coluna
		
		tabelaString [posicaoLinha][posicaoColuna] = gerente.getSalarioLiquido();
		posicaoColuna = 0;
		posicaoLinha++; // Incrementa a Varivel linha
	
	}
	
	
	// Determina os titulos das coluna da lista
	String colunasTitulos[] = {"Nome", "CPF", "Regional", "Meta Regional", "Salário Liquido"};
	
	//Cria o frame (janela)
	JFrame frameListarGerente = new JFrame();
	frameListarGerente.setSize(500,600);
	
	//Cria o objeto do tipo tabela (interface grafica)
	JTable tabelaGerente = new JTable(tabelaString,colunasTitulos);
	tabelaGerente.setBounds(30,40,200,300);
	
	//Scroll
	JScrollPane scrollPaneTabela = new JScrollPane(tabelaGerente);
	JPanel panelListarGerente = new JPanel();
	
	panelListarGerente.add(scrollPaneTabela);
	
	frameListarGerente.add(panelListarGerente);
	frameListarGerente.setVisible(true);
	
	JTextField cpfTextField = new JTextField(10);
	panelListarGerente.add(cpfTextField);
	
	JButton botaoDeletar = new JButton("Excluir");
	panelListarGerente.add(botaoDeletar);
	
	panelListarGerente.add(scrollPaneTabela);

	frameListarGerente.add(panelListarGerente);
	frameListarGerente.setVisible(true);
	                                                                       				  
	TelaDeletarGerenteControle telaDeletarGerenteControle = new TelaDeletarGerenteControle(frameListarGerente, frameMenuInicial, cpfTextField, repositorioGerente);
	botaoDeletar.addActionListener(telaDeletarGerenteControle);
	}

}
