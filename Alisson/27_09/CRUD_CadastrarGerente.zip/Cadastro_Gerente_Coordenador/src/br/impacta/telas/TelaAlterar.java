package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.impacta.model.Programador;
import br.impacta.repositorio.RepositorioProgramador;
import br.impacta.telas.controleTelas.TelaAlterarControle;

public class TelaAlterar {

	public void alterarProgramador(JFrame frameMenuInicial, RepositorioProgramador repositorioProgramador, Programador programadorAtual) {
	
	
	// Strings que serão usadas na Label
			String nomeTexto = "Digite o nome do progrador:";
			String cpfTexto = "Digite o CPF:";
			String estadoTexto = "Digite o Estado:";
			
			
			
			// Criação do Frame (Janela)
			JFrame frameTelaAlterar = new JFrame();
			frameTelaAlterar.setSize(200, 300);
			frameTelaAlterar.setTitle("Inserir Programador");
			frameTelaAlterar.setLocation(300,300);
			
			//Criação do painel
			JPanel painelTelaAlterar = new JPanel();
			
			//Criação da Labels
			JLabel nomeTextoLabel = new JLabel(nomeTexto );
			painelTelaAlterar.add(nomeTextoLabel);
			
			//Criação da Caixa de texto
			JTextField nomeTextField = new JTextField(10);
			nomeTextField.setText(programadorAtual.getNome()); // Adiciona na caixa de texto os valores do programador que será alterado
			painelTelaAlterar.add(nomeTextField);
			
			
			JLabel cpfTextoLabel = new JLabel(cpfTexto);
			painelTelaAlterar.add(cpfTextoLabel);
			
			JTextField cpfTextField = new JTextField(10);
			cpfTextField.setText(programadorAtual.getCpf());
			painelTelaAlterar.add(cpfTextField);
			
			JLabel estadoTextoLabel = new JLabel(estadoTexto);
			painelTelaAlterar.add(estadoTextoLabel);
			
			JTextField estadoTextField = new JTextField(10);
			estadoTextField.setText(programadorAtual.getEstado());
			painelTelaAlterar.add(estadoTextField);
			
			//Criação do botão
			JButton botaoAlterar = new JButton("Alterar");
			painelTelaAlterar.add(botaoAlterar);
			
			// Adiciona o painel "dentro" do frame(janela)
			frameTelaAlterar.add(painelTelaAlterar);
			
			//Habilitar visibilidade do frame(janela)
			frameTelaAlterar.setVisible(true);
			
			TelaAlterarControle alterarControle = new TelaAlterarControle(frameTelaAlterar, frameMenuInicial, nomeTextField, cpfTextField, estadoTextField, repositorioProgramador, programadorAtual);
			botaoAlterar.addActionListener(alterarControle);
	
}
	
	
	
	
	
}
