package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import br.impacta.model.Programador;
import br.impacta.repositorio.RepositorioProgramador;
import br.impacta.telas.controleTelas.TelaDeletarControle;

public class TelaDeletar {

	
	public void deletarProgramador(JFrame menuInicialFrame, RepositorioProgramador repositorioProgramador) {
		
		//Determina a quantidade de linhas da tabela
				int quantidadeDeLinhas = repositorioProgramador.listarProgramador().size();
				// Determina a quantidade de colunas
				int quantidadeDeColunas = 3;
				
				String stringTextoDeletar = "Digite o cpf que deseja deletar:";
				
				// Determina a matrix os itens de linhas e colunas da tabela
				
				String [][] tabelaString = new String [quantidadeDeLinhas][quantidadeDeColunas];
				
				int posicaoLinha = 0; // Determina a posição da coluna
				int posicaoColuna = 0;// Determina a posição da linha
				
				// Percorrer todos os itens da lista 
				for(Programador programador: repositorioProgramador.listarProgramador()) {
					
					//Adiciona a String Nome na celula atual de acordo com o valor das variaveis 
					//posição linha e coluna
					tabelaString [posicaoLinha][posicaoColuna] = programador.getNome();
					
					posicaoColuna++; // Incrementa a variavel coluna
					
					tabelaString [posicaoLinha][posicaoColuna] = programador.getCpf();
					posicaoColuna++;// Incrementa a variavel coluna
					
					
					tabelaString [posicaoLinha][posicaoColuna] = programador.getEstado();
					posicaoColuna = 0;
					posicaoLinha++; // Incrementa a Varivel linha
				
				}
				
				
				// Determina os titulos das coluna da lista
				String colunasTitulos[] = {"Nome", "Cpf", "Estado"};
				
				//Cria o frame (janela)
				JFrame frameListarProgramador = new JFrame();
				frameListarProgramador.setSize(500,600);
				
				//Cria o objeto do tipo tabela (interface grafica)
				JTable tabelaProgramador = new JTable(tabelaString,colunasTitulos);
				tabelaProgramador.setBounds(30,40,200,300);
				
				//Scroll
				JScrollPane scrollPaneTabela = new JScrollPane(tabelaProgramador);
				JPanel panelListarProgramador = new JPanel();
				
				JLabel stringTextoDeletarLabel = new JLabel(stringTextoDeletar);
				panelListarProgramador.add(stringTextoDeletarLabel);
				
				JTextField cpfTextField = new JTextField(10);
				panelListarProgramador.add(cpfTextField);
				
				JButton botaoDeletar = new JButton("Deletar");
				panelListarProgramador.add(botaoDeletar);
				
				
				// Adiciona o scroll pane no painel
				panelListarProgramador.add(scrollPaneTabela);
				
				// Adiciona o painel no frame e habilita a visibilidade do frame
				frameListarProgramador.add(panelListarProgramador);
				frameListarProgramador.setVisible(true);
				
				TelaDeletarControle telaDeletarControle = new TelaDeletarControle(frameListarProgramador, menuInicialFrame, cpfTextField, repositorioProgramador);
				botaoDeletar.addActionListener(telaDeletarControle);
	}
	
}
