package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.BuscarGerenteEditar;
import br.impacta.telas.ListarGerente;
import br.impacta.telas.TelaDeletarGerente;
import br.impacta.telas.TelaRegistroGerente;

public class MenuInicialFuncionarioControle implements ActionListener{
	
	JTextField opcaoMenuJTextField;
	JFrame frameMenuInicial;
	
	RepositorioGerente repositorioGerente = new RepositorioGerente();
	
	ListarGerente listarGerente = new ListarGerente();
	
	TelaRegistroGerente registroGerente = new TelaRegistroGerente();
	
	BuscarGerenteEditar buscarGerenteEditar = new BuscarGerenteEditar();
	
	TelaDeletarGerente deletarGerente = new TelaDeletarGerente();

	public MenuInicialFuncionarioControle(JTextField opcaoMenuJTextFieldCr,JFrame frameMenuInicialCr) {
		this.opcaoMenuJTextField = opcaoMenuJTextFieldCr;
		this.frameMenuInicial = frameMenuInicialCr;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(opcaoMenuJTextField.getText().equals("1")|| opcaoMenuJTextField.getText().equals("3") || opcaoMenuJTextField.getText().equals("4")
				|| opcaoMenuJTextField.getText().equals("6")){
			
			frameMenuInicial.setVisible(false);
			
			switch (opcaoMenuJTextField.getText()) {
			case "1":
				registroGerente.registrarGerente(opcaoMenuJTextField, frameMenuInicial, repositorioGerente);
				
				System.out.println("Cadastre o Gerente!");
				break;
				
			case "3":
				
				listarGerente.apresentarLista(repositorioGerente.listarGerente(), frameMenuInicial);
				System.out.println("Lista de Gerente");
				break;
				
			case "5":
				
				deletarGerente.deletarGerente(frameMenuInicial, repositorioGerente);
				break;
				
			case "4":
				System.out.println("Você encerrou");
				break;
				
			case "6":
				
				buscarGerenteEditar.buscarGerente(frameMenuInicial, repositorioGerente);
				System.out.println("Lista de Gerente");
				break;
			
			}
		}else {
			
			System.out.println("Opção Invalida!!");
		}
		
	}

}
