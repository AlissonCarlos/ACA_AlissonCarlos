package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.validacao.ValidarGerente;

public class TelaAlterarGerenteControle implements ActionListener {

	JFrame frameTelaRegistro;
	JFrame frameMenuInicial;
	
	JTextField nomeTextField;
	JTextField cpfTextField;
	JTextField estadoTextField;
	JTextField regionalTextField;
	JTextField metaRegionalTextField;
	JTextField salarioLiquidoTextField;
	
	//Iniciar o repositorio geral da aplicação. 
	RepositorioGerente repositorioGerente;
	
	Gerente gerenteAtual;
	
	boolean validaAlterar = false;
	
	ValidarGerente validarGerente = new ValidarGerente();
	
	String msgErro;

	//Contrutor recebendo os parametros(sobrecarga)
	public TelaAlterarGerenteControle(JFrame frameTelaRegistro, JFrame frameMenuInicial, JTextField nomeTextField,
			JTextField cpfTextField, JTextField estadoTextField, JTextField regionalTextField, JTextField metaRegionalTextField, JTextField salarioLiquidoTextField, RepositorioGerente repositorioGerente, Gerente gerenteAtual) {
		super();
		this.frameTelaRegistro = frameTelaRegistro;
		this.frameMenuInicial = frameMenuInicial;
		this.nomeTextField = nomeTextField;
		this.cpfTextField = cpfTextField;
		this.estadoTextField = estadoTextField;
		this.regionalTextField = regionalTextField;
		this.metaRegionalTextField = metaRegionalTextField;
		this.salarioLiquidoTextField = salarioLiquidoTextField;
		this.repositorioGerente = repositorioGerente;
		this.gerenteAtual = gerenteAtual;
	}
	
	public TelaAlterarGerenteControle() {
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		acionarAlterar();
		frameMenuInicial.setVisible(true);
		frameTelaRegistro.setVisible(false);
		
	}

	private void acionarAlterar() {
		
		Gerente gerenteNovo = new Gerente();
		gerenteNovo.setNome(nomeTextField.getText());
		gerenteNovo.setCpf(cpfTextField.getText());
		gerenteNovo.setRegional(estadoTextField.getText());
		gerenteNovo.setMetaRegional(metaRegionalTextField.getText());
		gerenteNovo.setSalarioLiquido(salarioLiquidoTextField.getText());
		
		
		msgErro = validarGerente.validarGerente(gerenteNovo, repositorioGerente, "Alterar");
		
		if(msgErro == null) {
			validaAlterar = repositorioGerente.alterarGerente(gerenteAtual, gerenteNovo);
			
			if(validaAlterar) {
				JOptionPane.showMessageDialog(null,gerenteNovo.getNome() + "Foi Alterado!!");
			}else {
				JOptionPane.showMessageDialog(null,"Erro na Alteração!!");
			}
		}else {
			JOptionPane.showMessageDialog(null,msgErro);
		}	
		
	}
	
	
	
	
	
}
