package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.model.Programador;
import br.impacta.repositorio.RepositorioProgramador;

public class TelaAlterarControle implements ActionListener {
	
	JFrame frameTelaAlterar;
	JFrame frameMenuInicial;
	JTextField nomeTextField;
	JTextField cpfTextField;
	JTextField estadoTextField;
	
	RepositorioProgramador repositorioProgramador;
	Programador programadorAtual;
	
	boolean validaAlterar;
	
	public TelaAlterarControle(JFrame frameTelaAlterar, JFrame frameMenuInicial, JTextField nomeTextField,
			JTextField cpfTextField, JTextField estadoTextField, RepositorioProgramador repositorioProgramador,
			Programador programadorAtual) {
		super();
		this.frameTelaAlterar = frameTelaAlterar;
		this.frameMenuInicial = frameMenuInicial;
		this.nomeTextField = nomeTextField;
		this.cpfTextField = cpfTextField;
		this.estadoTextField = estadoTextField;
		this.repositorioProgramador = repositorioProgramador;
		this.programadorAtual = programadorAtual;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		acionarAlterar();
		frameMenuInicial.setVisible(true);
		frameTelaAlterar.setVisible(false);
		
		
	}

	private void acionarAlterar() {
	Programador programadorNovo = new Programador();
	
	programadorNovo.setNome(nomeTextField.getText());
	programadorNovo.setCpf(cpfTextField.getText());
	programadorNovo.setEstado(estadoTextField.getText());
	
	validaAlterar = repositorioProgramador.alterarProgramador(programadorAtual, programadorNovo);
	
	if(validaAlterar) {
		JOptionPane.showMessageDialog(null,programadorNovo.getNome() + "Foi Alterado!!");
	}else {
		JOptionPane.showMessageDialog(null,"Erro na Alteração!!");
	}
	
	}
	
	
	
	
	
	
	
}
