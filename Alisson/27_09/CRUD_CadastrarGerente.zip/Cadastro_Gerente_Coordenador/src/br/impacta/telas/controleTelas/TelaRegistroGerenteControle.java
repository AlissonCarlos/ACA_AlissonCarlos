package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;

public class TelaRegistroGerenteControle implements ActionListener {

	JFrame frameTelaRegistro;
	JFrame frameMenuInicial;
	
	JTextField nomeTextField;
	JTextField cpfTextField;
	JTextField estadoTextField;
	JTextField regionalTextField;
	JTextField metaRegionalTextField;
	JTextField salarioLiquidoTextField;
	
	//Iniciar o repositorio geral da aplicação. 
	RepositorioGerente repositorioGerente;
	
	boolean validarSalvar = false;

	//Contrutor recebendo os parametros(sobrecarga)
	public TelaRegistroGerenteControle(JFrame frameTelaRegistro, JFrame frameMenuInicial, JTextField nomeTextField,
			JTextField cpfTextField, JTextField estadoTextField, JTextField regionalTextField, JTextField metaRegionalTextField, JTextField salarioLiquidoTextField, RepositorioGerente repositorioGerente) {
		super();
		this.frameTelaRegistro = frameTelaRegistro;
		this.frameMenuInicial = frameMenuInicial;
		this.nomeTextField = nomeTextField;
		this.cpfTextField = cpfTextField;
		this.estadoTextField = estadoTextField;
		this.regionalTextField = regionalTextField;
		this.metaRegionalTextField = metaRegionalTextField;
		this.salarioLiquidoTextField = salarioLiquidoTextField;
		this.repositorioGerente = repositorioGerente;
	}
	
	public TelaRegistroGerenteControle() {
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		acionarSalvar();
		frameMenuInicial.setVisible(true);
		frameTelaRegistro.setVisible(false);
		
	}

	
	//Inseri o evento da lista do repositorio.
	private void acionarSalvar() {
		
		Gerente gerente = new Gerente();
		gerente.setNome(nomeTextField.getText());
		gerente.setCpf(cpfTextField.getText());
		gerente.setRegional(estadoTextField.getText());
		gerente.setMetaRegional(metaRegionalTextField.getText());
		gerente.setSalarioLiquido(salarioLiquidoTextField.getText());
		
		
		validarSalvar = repositorioGerente.salvarGerente(gerente);
		
		if(validarSalvar) {
			JOptionPane.showMessageDialog(null, gerente.getNome() + " Foi Registrado com sucesso!");
		}else {
			JOptionPane.showMessageDialog(null, "Erro ao Cadastrar");
			System.out.println("Erro durante o cadastro");
		}
		
	}
	
	
	
	
	
}
