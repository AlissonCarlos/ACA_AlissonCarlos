package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.controleTelas.TelaRegistroGerenteControle;

public class TelaRegistroGerente {
	
public void  registrarGerente(JTextField opcaoMenuJTextField, JFrame frameMenuInicial, RepositorioGerente repositorioGerente) {
		
		String nomeTexto = "Digite o nome:";
		String cpfTexto = "Digite o CPF:";
		String estadoTexto = "Digite o Estado:";
		String regionalTexto = "Digite a Regional";
		String metaRegional = "Digite a Meta Regional";
		String salarioLiquido = "Digite o Salario";
		
		JFrame frameTelaRegistro = new JFrame();
		frameTelaRegistro.setSize(300, 400);
		frameTelaRegistro.setTitle("Inserir Gerente");
		frameTelaRegistro.setLocation(500,500);
		
		JPanel painelTelaRegistro = new JPanel();
		
		JLabel nomeTextoLabel = new JLabel(nomeTexto );
		painelTelaRegistro.add(nomeTextoLabel);
		
		JTextField nomeTextField = new JTextField(10);
		painelTelaRegistro.add(nomeTextField);
		
		
		JLabel cpfTextoLabel = new JLabel(cpfTexto);
		painelTelaRegistro.add(cpfTextoLabel);
		
		JTextField cpfTextField = new JTextField(10);
		painelTelaRegistro.add(cpfTextField);
		
		JLabel estadoTextoLabel = new JLabel(estadoTexto);
		painelTelaRegistro.add(estadoTextoLabel);
		
		JTextField estadoTextField = new JTextField(10);
		painelTelaRegistro.add(estadoTextField);
		
		JLabel regionalTextoLabel = new JLabel(regionalTexto);
		painelTelaRegistro.add(regionalTextoLabel);
		
		JTextField regionalTextField = new JTextField(10);
		painelTelaRegistro.add(regionalTextField);
		
		JLabel metaRegionalLabel = new JLabel(metaRegional);
		painelTelaRegistro.add(metaRegionalLabel);
		
		JTextField metaRegionalTextField = new JTextField(10);
		painelTelaRegistro.add(metaRegionalTextField);
		
		JLabel salarioLiquidoLabel = new JLabel(salarioLiquido);
		painelTelaRegistro.add(salarioLiquidoLabel);
		
		JTextField salarioLiquidoTextField = new JTextField(10);
		painelTelaRegistro.add(salarioLiquidoTextField);
		
		JButton botaoCadastrar = new JButton("Registrar");
		painelTelaRegistro.add(botaoCadastrar);
		
		frameTelaRegistro.add(painelTelaRegistro);
		
		frameTelaRegistro.setVisible(true);
		
		TelaRegistroGerenteControle telaRegistroGerenteControle = 
				new TelaRegistroGerenteControle(frameTelaRegistro, frameMenuInicial, nomeTextField, 
						cpfTextField, estadoTextField, regionalTextField, metaRegionalTextField, salarioLiquidoTextField,
						repositorioGerente);
		
		botaoCadastrar.addActionListener(telaRegistroGerenteControle);
	}

}
