package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.repositorio.RepositorioGerente;

public class TelaDeletarGerenteControle implements ActionListener{

	JFrame frameListarGerente;
	JFrame menuInicialFrame;
	JTextField cpfField;
	RepositorioGerente repositorioGerente;
	
	boolean validaDelete;
	
	public TelaDeletarGerenteControle(JFrame frameListarProgramador, JFrame menuInicialFrame, JTextField cpfField,
			RepositorioGerente repositorioGerente) {
		super();
		this.frameListarGerente = frameListarProgramador;
		this.menuInicialFrame = menuInicialFrame;
		this.cpfField = cpfField;
		this.repositorioGerente = repositorioGerente;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		validaDelete = repositorioGerente.deletarGerente(cpfField.getText());
	
		if(validaDelete) {
			JOptionPane.showMessageDialog(null, "Gerente excluido com Sucesso");
			menuInicialFrame.setVisible(true);
			frameListarGerente.setVisible(false);
			
		}else {
			JOptionPane.showMessageDialog(null, "Gerente não encontrado!!");
			menuInicialFrame.setVisible(true);
			frameListarGerente.setVisible(false);
		
		}
		
		
	
	}
	
	
	
	
	
}
