package br.impacta.telas.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.model.Programador;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.repositorio.RepositorioProgramador;
import br.impacta.telas.TelaAlterarGerente;

public class BuscarGerenteControle implements ActionListener {
	
	JFrame frameListarGerente;
	JFrame frameMenuInicial;
	JTextField cpfField;
	
	RepositorioGerente repositorioGerente;
	
	TelaAlterarGerente telaAlterar = new TelaAlterarGerente();
	
	public BuscarGerenteControle(JFrame frameListarGerente, JFrame frameMenuInicial, JTextField cpfField,
			RepositorioGerente repositorioGerente) {
		super();
		this.frameListarGerente = frameListarGerente;
		this.frameMenuInicial = frameMenuInicial;
		this.cpfField = cpfField;
		this.repositorioGerente = repositorioGerente;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		Gerente gerenteAtual = new Gerente();
		
		gerenteAtual = repositorioGerente.BuscarGerente(cpfField.getText());
		
		if (!(gerenteAtual == null)) {
			frameListarGerente.setVisible(false);
			telaAlterar.alterarGerente(frameMenuInicial, repositorioGerente, gerenteAtual);
		}
	
	}

}
