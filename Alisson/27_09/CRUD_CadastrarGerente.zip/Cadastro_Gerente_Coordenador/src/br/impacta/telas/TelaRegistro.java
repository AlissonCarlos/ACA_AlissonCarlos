package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.impacta.repositorio.RepositorioProgramador;
import br.impacta.telas.controleTelas.TelaRegistroControle;

public class TelaRegistro {

	
	public void  registrarProgramador(JTextField opcaoMenuJText, JFrame frameMenuInicial, RepositorioProgramador repositorioProgramador) {
		
		// Strings que serão usadas na Label
		String nomeTexto = "Digite o nome do programador:";
		String cpfTexto = "Digite o CPF:";
		String estadoTexto = "Digite o Estado:";
		
		// Criação do Frame (Janela)
		JFrame frameTelaRegistro = new JFrame();
		frameTelaRegistro.setSize(200, 300);
		frameTelaRegistro.setTitle("Inserir Programador");
		frameTelaRegistro.setLocation(300,300);
		
		//Criação do painel
		JPanel painelTelaRegistro = new JPanel();
		
		//Criação da Labels
		JLabel nomeTextoLabel = new JLabel(nomeTexto );
		painelTelaRegistro.add(nomeTextoLabel);
		
		//Criação da Caixa de texto
		JTextField nomeTextField = new JTextField(10);
		painelTelaRegistro.add(nomeTextField);
		
		
		JLabel cpfTextoLabel = new JLabel(cpfTexto);
		painelTelaRegistro.add(cpfTextoLabel);
		
		JTextField cpfTextField = new JTextField(10);
		painelTelaRegistro.add(cpfTextField);
		
		JLabel estadoTextoLabel = new JLabel(estadoTexto);
		painelTelaRegistro.add(estadoTextoLabel);
		
		JTextField estadoTextField = new JTextField(10);
		painelTelaRegistro.add(estadoTextField);
		
		//Criação do botão
		JButton botaoCadastrar = new JButton("Registrar");
		painelTelaRegistro.add(botaoCadastrar);
		
		// Adiciona o painel "dentro" do frame(janela)
		frameTelaRegistro.add(painelTelaRegistro);
		
		//Habilitar visibilidade do frame(janela)
		frameTelaRegistro.setVisible(true);
		
		//Realiaza chamada do controlador enviado os parametros do objeto "programador" através do construtor.
		TelaRegistroControle telaRegistroControle = new TelaRegistroControle(frameTelaRegistro, frameMenuInicial, nomeTextField, cpfTextField, estadoTextField, repositorioProgramador);
		
		//Adicionar(relacionar) o botão da tela com o metodo de ação(actionPerformed)
		botaoCadastrar.addActionListener(telaRegistroControle);
	}
	
	
}
