package br.impacta.model;

public class Coordenador extends Funcionario{

	private String loja;
	private Double metaDaLoja;

	public String getLoja() {
		return loja;
	}

	public void setLoja(String loja) {
		this.loja = loja;
	}

	public Double getMetaDaLoja() {
		return metaDaLoja;
	}

	public void setMetaDaLoja(Double metaDaLoja) {
		this.metaDaLoja = metaDaLoja;
	}

}
