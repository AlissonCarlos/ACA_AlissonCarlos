package br.impacta.model;


public class Programador extends Pessoa {

		private String nivel;
//		private LinguagemProgramacao linguagem;

		public String getNivel() {
			return nivel;
		}

		public void setNivel(String nivel) {
			this.nivel = nivel;
		}
		
}
