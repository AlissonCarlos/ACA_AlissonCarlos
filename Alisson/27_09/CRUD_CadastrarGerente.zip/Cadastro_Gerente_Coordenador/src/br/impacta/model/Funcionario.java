package br.impacta.model;

public class Funcionario {
	private String nome;
	private String cpf;
	//alterar para double
	private String salarioLiquido;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getSalarioLiquido() {
		return salarioLiquido;
	}

	public void setSalarioLiquido(String salarioLiquido) {
		this.salarioLiquido = salarioLiquido;
	}

}
