package br.impacta.model;

public class Gerente extends Funcionario{

	private String Regional;
	//alterar para double
	private String MetaRegional;

	public String getRegional() {
		return Regional;
	}

	public void setRegional(String regional) {
		Regional = regional;
	}

	public String getMetaRegional() {
		return MetaRegional;
	}

	public void setMetaRegional(String metaRegional) {
		MetaRegional = metaRegional;
	}

}
